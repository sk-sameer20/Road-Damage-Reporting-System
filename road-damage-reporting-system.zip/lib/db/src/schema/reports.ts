import { pgTable, text, serial, real, timestamp, pgEnum } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod/v4";

export const damageTypeEnum = pgEnum("damage_type", [
  "pothole",
  "crack",
  "road_collapse",
  "flooding",
  "construction_damage",
]);

export const reportStatusEnum = pgEnum("report_status", [
  "pending",
  "in_progress",
  "resolved",
]);

export const reportsTable = pgTable("reports", {
  id: serial("id").primaryKey(),
  reportId: text("report_id").notNull().unique(),
  name: text("name").notNull(),
  email: text("email").notNull(),
  phone: text("phone").notNull(),
  damageType: damageTypeEnum("damage_type").notNull(),
  description: text("description").notNull(),
  imageUrl: text("image_url"),
  latitude: real("latitude"),
  longitude: real("longitude"),
  address: text("address"),
  status: reportStatusEnum("status").notNull().default("pending"),
  createdAt: timestamp("created_at").notNull().defaultNow(),
  updatedAt: timestamp("updated_at").notNull().defaultNow(),
});

export const insertReportSchema = createInsertSchema(reportsTable).omit({
  id: true,
  reportId: true,
  status: true,
  createdAt: true,
  updatedAt: true,
});

export const createReportSchema = z.object({
  name: z.string().min(1),
  email: z.email(),
  phone: z.string().min(1),
  damageType: z.enum([
    "pothole",
    "crack",
    "road_collapse",
    "flooding",
    "construction_damage",
  ]),
  description: z.string().min(1),
  imageUrl: z.string().nullish(),
  latitude: z.number().nullish(),
  longitude: z.number().nullish(),
  address: z.string().nullish(),
});

export const updateReportSchema = z.object({
  status: z.enum(["pending", "in_progress", "resolved"]).optional(),
  damageType: z
    .enum([
      "pothole",
      "crack",
      "road_collapse",
      "flooding",
      "construction_damage",
    ])
    .optional(),
  description: z.string().optional(),
  address: z.string().nullish(),
});

export type InsertReport = z.infer<typeof insertReportSchema>;
export type Report = typeof reportsTable.$inferSelect;
