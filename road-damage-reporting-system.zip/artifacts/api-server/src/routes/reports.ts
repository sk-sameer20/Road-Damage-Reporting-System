import { Router, type IRouter, type Request, type Response } from "express";
import { db, reportsTable } from "@workspace/db";
import { eq, desc, asc, ilike, and, sql, count } from "drizzle-orm";
import { createReportSchema, updateReportSchema } from "@workspace/db";

const router: IRouter = Router();

function generateReportId(): string {
  const timestamp = Date.now().toString(36).toUpperCase();
  const random = Math.random().toString(36).substring(2, 6).toUpperCase();
  return `RD-${timestamp}-${random}`;
}

router.get("/stats/summary", async (_req: Request, res: Response) => {
  try {
    const allReports = await db.select().from(reportsTable);
    const total = allReports.length;
    const pending = allReports.filter((r) => r.status === "pending").length;
    const inProgress = allReports.filter(
      (r) => r.status === "in_progress"
    ).length;
    const resolved = allReports.filter((r) => r.status === "resolved").length;

    const byDamageType: Record<string, number> = {};
    for (const r of allReports) {
      byDamageType[r.damageType] = (byDamageType[r.damageType] || 0) + 1;
    }

    const monthlyMap: Record<string, number> = {};
    for (const r of allReports) {
      const d = new Date(r.createdAt);
      const key = `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}`;
      monthlyMap[key] = (monthlyMap[key] || 0) + 1;
    }
    const monthlyTrend = Object.entries(monthlyMap)
      .sort(([a], [b]) => a.localeCompare(b))
      .slice(-12)
      .map(([month, count]) => ({ month, count }));

    const mostCommonType =
      Object.entries(byDamageType).sort(([, a], [, b]) => b - a)[0]?.[0] ||
      "none";

    res.json({
      total,
      pending,
      inProgress,
      resolved,
      byDamageType,
      monthlyTrend,
      mostCommonType,
    });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: "Internal server error" });
  }
});

router.get("/", async (req: Request, res: Response) => {
  try {
    const { damageType, status, search, sortBy, page = "1", limit = "10" } = req.query as Record<string, string>;

    const pageNum = Math.max(1, parseInt(page, 10) || 1);
    const limitNum = Math.min(100, Math.max(1, parseInt(limit, 10) || 10));
    const offset = (pageNum - 1) * limitNum;

    const conditions = [];
    if (damageType) {
      conditions.push(eq(reportsTable.damageType, damageType as any));
    }
    if (status) {
      conditions.push(eq(reportsTable.status, status as any));
    }
    if (search) {
      conditions.push(
        ilike(reportsTable.description, `%${search}%`)
      );
    }

    const whereClause = conditions.length > 0 ? and(...conditions) : undefined;
    const orderClause = sortBy === "oldest" ? asc(reportsTable.createdAt) : desc(reportsTable.createdAt);

    const [reports, totalResult] = await Promise.all([
      db
        .select()
        .from(reportsTable)
        .where(whereClause)
        .orderBy(orderClause)
        .limit(limitNum)
        .offset(offset),
      db
        .select({ count: count() })
        .from(reportsTable)
        .where(whereClause),
    ]);

    const total = totalResult[0]?.count || 0;
    const totalPages = Math.ceil(total / limitNum);

    res.json({ reports, total, page: pageNum, limit: limitNum, totalPages });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: "Internal server error" });
  }
});

router.post("/", async (req: Request, res: Response) => {
  try {
    const data = createReportSchema.parse(req.body);
    const reportId = generateReportId();

    const [report] = await db
      .insert(reportsTable)
      .values({
        ...data,
        reportId,
        imageUrl: data.imageUrl ?? null,
        latitude: data.latitude ?? null,
        longitude: data.longitude ?? null,
        address: data.address ?? null,
      })
      .returning();

    res.status(201).json(report);
  } catch (err: any) {
    console.error(err);
    if (err?.name === "ZodError" || err?.issues) {
      res.status(400).json({ error: "Invalid request data", details: err.issues });
    } else {
      res.status(500).json({ error: "Internal server error" });
    }
  }
});

router.get("/:id", async (req: Request, res: Response) => {
  try {
    const id = parseInt(req.params.id, 10);
    if (isNaN(id)) return res.status(400).json({ error: "Invalid ID" });

    const [report] = await db
      .select()
      .from(reportsTable)
      .where(eq(reportsTable.id, id));

    if (!report) return res.status(404).json({ error: "Report not found" });
    res.json(report);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: "Internal server error" });
  }
});

router.put("/:id", async (req: Request, res: Response) => {
  try {
    const id = parseInt(req.params.id, 10);
    if (isNaN(id)) return res.status(400).json({ error: "Invalid ID" });

    const data = updateReportSchema.parse(req.body);

    const [report] = await db
      .update(reportsTable)
      .set({ ...data, updatedAt: new Date() })
      .where(eq(reportsTable.id, id))
      .returning();

    if (!report) return res.status(404).json({ error: "Report not found" });
    res.json(report);
  } catch (err: any) {
    console.error(err);
    if (err?.name === "ZodError" || err?.issues) {
      res.status(400).json({ error: "Invalid request data" });
    } else {
      res.status(500).json({ error: "Internal server error" });
    }
  }
});

router.delete("/:id", async (req: Request, res: Response) => {
  try {
    const id = parseInt(req.params.id, 10);
    if (isNaN(id)) return res.status(400).json({ error: "Invalid ID" });

    const [deleted] = await db
      .delete(reportsTable)
      .where(eq(reportsTable.id, id))
      .returning();

    if (!deleted) return res.status(404).json({ error: "Report not found" });
    res.status(204).send();
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: "Internal server error" });
  }
});

export default router;
