import { Router, type IRouter } from "express";
import healthRouter from "./health";
import reportsRouter from "./reports";
import uploadRouter from "./upload";

const router: IRouter = Router();

router.use(healthRouter);
router.use("/reports", reportsRouter);
router.use("/upload", uploadRouter);

export default router;
