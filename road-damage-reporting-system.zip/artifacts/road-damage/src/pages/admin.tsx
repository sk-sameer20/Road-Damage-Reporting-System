import { useState } from "react";
import { Link } from "wouter";
import { 
  useListReports, 
  useGetReportStats, 
  useUpdateReport, 
  useDeleteReport,
  Report 
} from "@workspace/api-client-react";
import { StatusBadge } from "@/components/ui/status-badge";
import { ReportsMap } from "@/components/map/map-helpers";
import { format } from "date-fns";
import { 
  LayoutDashboard, Map, List, BarChart3, Settings as SettingsIcon, 
  Trash2, CheckCircle2, AlertTriangle, Clock, RefreshCw, X
} from "lucide-react";
import { motion, AnimatePresence } from "framer-motion";

// ChartJS registration
import {
  Chart as ChartJS,
  CategoryScale,
  LinearScale,
  PointElement,
  LineElement,
  BarElement,
  Title,
  Tooltip,
  Legend,
  ArcElement,
  Filler
} from 'chart.js';
import { Line, Doughnut } from 'react-chartjs-2';

ChartJS.register(
  CategoryScale, LinearScale, PointElement, LineElement, BarElement,
  Title, Tooltip, Legend, ArcElement, Filler
);

function ConfirmDialog({ isOpen, onClose, onConfirm, title, message }: { isOpen: boolean, onClose: () => void, onConfirm: () => void, title: string, message: string }) {
  return (
    <AnimatePresence>
      {isOpen && (
        <div className="fixed inset-0 z-[100] flex items-center justify-center px-4">
          <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} className="absolute inset-0 bg-black/60 backdrop-blur-sm" onClick={onClose} />
          <motion.div initial={{ scale: 0.9, opacity: 0 }} animate={{ scale: 1, opacity: 1 }} exit={{ scale: 0.9, opacity: 0 }} className="bg-card w-full max-w-md p-6 rounded-2xl shadow-2xl relative z-10 border border-border">
            <h3 className="text-xl font-bold mb-2">{title}</h3>
            <p className="text-muted-foreground mb-6">{message}</p>
            <div className="flex justify-end space-x-3">
              <button onClick={onClose} className="px-4 py-2 rounded-lg font-medium hover:bg-secondary transition-colors">Cancel</button>
              <button onClick={() => { onConfirm(); onClose(); }} className="px-4 py-2 rounded-lg font-medium bg-destructive text-destructive-foreground hover:bg-destructive/90 transition-colors">Confirm</button>
            </div>
          </motion.div>
        </div>
      )}
    </AnimatePresence>
  );
}

export default function AdminPanel() {
  const [activeTab, setActiveTab] = useState('overview');
  const [isSidebarOpen, setIsSidebarOpen] = useState(true);
  
  const { data: stats, refetch: refetchStats } = useGetReportStats();
  const { data: reportsData, refetch: refetchReports } = useListReports({ limit: 100 });
  const updateReport = useUpdateReport();
  const deleteReport = useDeleteReport();

  const [deleteId, setDeleteId] = useState<number | null>(null);

  const handleStatusChange = (id: number, currentStatus: string, newStatus: 'pending' | 'in_progress' | 'resolved') => {
    if (currentStatus === newStatus) return;
    updateReport.mutate({ id, data: { status: newStatus } }, {
      onSuccess: () => {
        refetchReports();
        refetchStats();
      }
    });
  };

  const handleDelete = () => {
    if (!deleteId) return;
    deleteReport.mutate({ id: deleteId }, {
      onSuccess: () => {
        refetchReports();
        refetchStats();
        setDeleteId(null);
      }
    });
  };

  // Chart configs
  const doughnutData = {
    labels: ['Pothole', 'Crack', 'Road Collapse', 'Flooding', 'Construction'],
    datasets: [{
      data: stats ? [
        stats.byDamageType['pothole'] || 0,
        stats.byDamageType['crack'] || 0,
        stats.byDamageType['road_collapse'] || 0,
        stats.byDamageType['flooding'] || 0,
        stats.byDamageType['construction_damage'] || 0,
      ] : [],
      backgroundColor: ['#ef4444', '#f59e0b', '#7f1d1d', '#0ea5e9', '#8b5cf6'],
      borderWidth: 0,
      hoverOffset: 4
    }]
  };

  const trendData = {
    labels: stats?.monthlyTrend?.map(t => t.month) || [],
    datasets: [{
      label: 'Reports',
      data: stats?.monthlyTrend?.map(t => t.count) || [],
      borderColor: '#3b82f6',
      backgroundColor: 'rgba(59, 130, 246, 0.1)',
      fill: true,
      tension: 0.4
    }]
  };

  const chartOptions = {
    responsive: true, maintainAspectRatio: false,
    plugins: { legend: { position: 'bottom' as const, labels: { color: 'hsl(var(--foreground))' } } }
  };

  return (
    <div className="min-h-screen flex bg-background">
      {/* Sidebar */}
      <aside className={`bg-card border-r border-border transition-all duration-300 flex flex-col ${isSidebarOpen ? 'w-64' : 'w-20'}`}>
        <div className="h-20 flex items-center justify-center border-b border-border px-4">
          <Link href="/" className="flex items-center space-x-2">
            <div className="w-8 h-8 rounded-lg bg-primary flex items-center justify-center shrink-0">
              <img src={`${import.meta.env.BASE_URL}images/logo-mark.png`} alt="Logo" className="w-5 h-5 brightness-200" />
            </div>
            {isSidebarOpen && <span className="font-display font-bold text-xl tracking-tight">Admin Portal</span>}
          </Link>
        </div>
        
        <nav className="flex-1 p-4 flex flex-col space-y-2">
          {[
            { id: 'overview', label: 'Overview', icon: LayoutDashboard },
            { id: 'reports', label: 'Manage Reports', icon: List },
            { id: 'map', label: 'Map Monitor', icon: Map },
            { id: 'analytics', label: 'Analytics', icon: BarChart3 },
            { id: 'settings', label: 'Settings', icon: SettingsIcon },
          ].map(tab => (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id)}
              className={`flex items-center space-x-3 px-3 py-3 rounded-xl transition-all ${
                activeTab === tab.id 
                  ? "bg-primary text-primary-foreground shadow-md" 
                  : "text-muted-foreground hover:bg-secondary hover:text-foreground"
              }`}
            >
              <tab.icon className="w-5 h-5 shrink-0" />
              {isSidebarOpen && <span className="font-medium">{tab.label}</span>}
            </button>
          ))}
        </nav>
      </aside>

      {/* Main Content */}
      <main className="flex-1 flex flex-col overflow-hidden">
        {/* Top Header */}
        <header className="h-20 glass-panel flex items-center justify-between px-8 shrink-0">
          <div className="flex items-center">
            <button onClick={() => setIsSidebarOpen(!isSidebarOpen)} className="mr-4 p-2 rounded-lg hover:bg-secondary">
              <List className="w-5 h-5" />
            </button>
            <h2 className="text-xl font-bold capitalize">{activeTab.replace('_', ' ')}</h2>
          </div>
          <div className="flex items-center space-x-4">
            <div className="flex items-center space-x-2 bg-secondary px-4 py-2 rounded-full border border-border">
              <div className="w-2 h-2 rounded-full bg-success animate-pulse" />
              <span className="text-sm font-medium">System Online</span>
            </div>
          </div>
        </header>

        {/* Scrollable Content */}
        <div className="flex-1 overflow-auto p-8">
          
          {/* TAB: OVERVIEW */}
          {activeTab === 'overview' && (
            <div className="space-y-8 max-w-7xl mx-auto">
              <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
                <div className="bg-card p-6 rounded-2xl border border-border shadow-sm">
                  <div className="flex items-center text-muted-foreground mb-4"><AlertTriangle className="w-5 h-5 mr-2 text-primary" /> Total Reports</div>
                  <div className="text-4xl font-display font-bold">{stats?.total || 0}</div>
                </div>
                <div className="bg-card p-6 rounded-2xl border border-border shadow-sm">
                  <div className="flex items-center text-muted-foreground mb-4"><Clock className="w-5 h-5 mr-2 text-warning" /> Pending</div>
                  <div className="text-4xl font-display font-bold text-warning">{stats?.pending || 0}</div>
                </div>
                <div className="bg-card p-6 rounded-2xl border border-border shadow-sm">
                  <div className="flex items-center text-muted-foreground mb-4"><RefreshCw className="w-5 h-5 mr-2 text-info" /> In Progress</div>
                  <div className="text-4xl font-display font-bold text-info">{stats?.inProgress || 0}</div>
                </div>
                <div className="bg-card p-6 rounded-2xl border border-border shadow-sm">
                  <div className="flex items-center text-muted-foreground mb-4"><CheckCircle2 className="w-5 h-5 mr-2 text-success" /> Resolved</div>
                  <div className="text-4xl font-display font-bold text-success">{stats?.resolved || 0}</div>
                </div>
              </div>

              <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
                <div className="bg-card p-6 rounded-2xl border border-border shadow-sm h-96 flex flex-col">
                  <h3 className="font-bold text-lg mb-6">Reports by Damage Type</h3>
                  <div className="flex-1 relative">
                    <Doughnut data={doughnutData} options={chartOptions} />
                  </div>
                </div>
                <div className="bg-card p-6 rounded-2xl border border-border shadow-sm h-96 flex flex-col">
                  <h3 className="font-bold text-lg mb-6">Monthly Reporting Trend</h3>
                  <div className="flex-1 relative">
                    <Line data={trendData} options={chartOptions} />
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* TAB: REPORTS TABLE */}
          {activeTab === 'reports' && (
            <div className="bg-card rounded-2xl border border-border shadow-sm overflow-hidden max-w-7xl mx-auto">
              <div className="overflow-x-auto">
                <table className="w-full text-left border-collapse">
                  <thead>
                    <tr className="bg-secondary/50 border-b border-border">
                      <th className="p-4 font-semibold text-sm">ID / Date</th>
                      <th className="p-4 font-semibold text-sm">Damage Type</th>
                      <th className="p-4 font-semibold text-sm">Location</th>
                      <th className="p-4 font-semibold text-sm">Status</th>
                      <th className="p-4 font-semibold text-sm text-right">Actions</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-border">
                    {reportsData?.reports.map((report: Report) => (
                      <tr key={report.id} className="hover:bg-secondary/20 transition-colors">
                        <td className="p-4">
                          <div className="font-mono text-sm">{report.reportId}</div>
                          <div className="text-xs text-muted-foreground">{format(new Date(report.createdAt), "MMM d, yyyy")}</div>
                        </td>
                        <td className="p-4 capitalize">{report.damageType.replace('_', ' ')}</td>
                        <td className="p-4 text-sm max-w-xs truncate" title={report.address || ''}>
                          {report.address || `${report.latitude?.toFixed(4)}, ${report.longitude?.toFixed(4)}`}
                        </td>
                        <td className="p-4">
                          <StatusBadge status={report.status} />
                        </td>
                        <td className="p-4">
                          <div className="flex justify-end items-center space-x-2">
                            <select 
                              value={report.status}
                              onChange={(e) => handleStatusChange(report.id, report.status, e.target.value as any)}
                              className="bg-background border border-border rounded-lg text-sm px-2 py-1 outline-none focus:border-primary"
                            >
                              <option value="pending">Pending</option>
                              <option value="in_progress">In Progress</option>
                              <option value="resolved">Resolved</option>
                            </select>
                            <button 
                              onClick={() => setDeleteId(report.id)}
                              className="p-1.5 text-destructive hover:bg-destructive/10 rounded-lg transition-colors"
                              title="Delete Report"
                            >
                              <Trash2 className="w-4 h-4" />
                            </button>
                          </div>
                        </td>
                      </tr>
                    ))}
                    {(!reportsData || reportsData.reports.length === 0) && (
                      <tr>
                        <td colSpan={5} className="p-8 text-center text-muted-foreground">No reports found.</td>
                      </tr>
                    )}
                  </tbody>
                </table>
              </div>
            </div>
          )}

          {/* TAB: MAP */}
          {activeTab === 'map' && (
            <div className="h-[calc(100vh-12rem)] max-w-7xl mx-auto rounded-2xl overflow-hidden border border-border shadow-sm">
              <ReportsMap reports={reportsData?.reports || []} height="100%" />
            </div>
          )}

          {/* TAB: ANALYTICS & SETTINGS (Placeholder visuals for completeness) */}
          {(activeTab === 'analytics' || activeTab === 'settings') && (
            <div className="max-w-3xl mx-auto text-center py-20">
              <div className="w-24 h-24 bg-secondary rounded-full flex items-center justify-center mx-auto mb-6">
                {activeTab === 'analytics' ? <BarChart3 className="w-10 h-10 text-muted-foreground" /> : <SettingsIcon className="w-10 h-10 text-muted-foreground" />}
              </div>
              <h2 className="text-2xl font-bold mb-4 capitalize">{activeTab} Module</h2>
              <p className="text-muted-foreground">
                This specialized module is currently configured for read-only demonstration. Advanced {activeTab} capabilities will be unlocked in the next deployment phase.
              </p>
            </div>
          )}

        </div>
      </main>
      
      <ConfirmDialog 
        isOpen={deleteId !== null}
        onClose={() => setDeleteId(null)}
        onConfirm={handleDelete}
        title="Delete Report"
        message="Are you sure you want to permanently delete this report? This action cannot be undone."
      />
    </div>
  );
}
