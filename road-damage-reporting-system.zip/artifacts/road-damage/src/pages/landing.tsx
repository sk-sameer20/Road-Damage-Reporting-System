import { Link } from "wouter";
import { Navbar } from "@/components/layout/navbar";
import { motion } from "framer-motion";
import { ArrowRight, ShieldCheck, Map, Activity, Clock } from "lucide-react";
import { useGetReportStats } from "@workspace/api-client-react";

export default function Landing() {
  const { data: stats } = useGetReportStats();

  const container = {
    hidden: { opacity: 0 },
    show: {
      opacity: 1,
      transition: { staggerChildren: 0.1 }
    }
  };

  const item = {
    hidden: { opacity: 0, y: 20 },
    show: { opacity: 1, y: 0, transition: { type: "spring", stiffness: 300, damping: 24 } }
  };

  return (
    <div className="min-h-screen bg-background relative overflow-hidden">
      <Navbar />
      
      {/* Background with AI image and overlay */}
      <div className="absolute inset-0 z-0">
        <div className="absolute inset-0 bg-gradient-to-b from-background/40 via-background/80 to-background z-10" />
        <img 
          src={`${import.meta.env.BASE_URL}images/hero-bg.png`}
          alt="Abstract civic infrastructure" 
          className="w-full h-[80vh] object-cover opacity-60 dark:opacity-30 mix-blend-overlay"
        />
      </div>

      <main className="relative z-10 pt-32 pb-16 px-4 sm:px-6 lg:px-8 max-w-7xl mx-auto">
        {/* Hero Section */}
        <div className="text-center max-w-4xl mx-auto pt-16 pb-24">
          <motion.div
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ duration: 0.6, ease: "easeOut" }}
            className="inline-flex items-center space-x-2 px-4 py-2 rounded-full bg-primary/10 text-primary font-semibold text-sm mb-8 border border-primary/20"
          >
            <span className="relative flex h-2.5 w-2.5">
              <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-primary opacity-75"></span>
              <span className="relative inline-flex rounded-full h-2.5 w-2.5 bg-primary"></span>
            </span>
            <span>Live Civic Reporting System</span>
          </motion.div>
          
          <motion.h1 
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.7, delay: 0.1 }}
            className="text-5xl md:text-7xl font-extrabold tracking-tight mb-8 leading-tight"
          >
            Empowering Citizens,<br />
            <span className="text-transparent bg-clip-text bg-gradient-to-r from-primary to-info">
              Improving Infrastructure
            </span>
          </motion.h1>
          
          <motion.p 
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.7, delay: 0.2 }}
            className="text-xl text-muted-foreground mb-12 max-w-2xl mx-auto leading-relaxed"
          >
            Help keep our city moving safely. Report potholes, cracks, and other road hazards in seconds. Track repair progress in real-time.
          </motion.p>
          
          <motion.div 
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.7, delay: 0.3 }}
            className="flex flex-col sm:flex-row items-center justify-center space-y-4 sm:space-y-0 sm:space-x-6"
          >
            <Link 
              href="/report" 
              className="w-full sm:w-auto px-8 py-4 rounded-xl font-bold text-lg bg-gradient-to-r from-primary to-info text-primary-foreground shadow-xl shadow-primary/25 hover:shadow-2xl hover:shadow-primary/40 hover:-translate-y-1 transition-all duration-300 flex items-center justify-center group"
            >
              <span>Report Damage</span>
              <ArrowRight className="ml-2 w-5 h-5 group-hover:translate-x-1 transition-transform" />
            </Link>
            
            <Link 
              href="/dashboard" 
              className="w-full sm:w-auto px-8 py-4 rounded-xl font-bold text-lg bg-card border-2 border-border hover:border-primary/50 text-foreground shadow-lg shadow-black/5 hover:shadow-xl hover:-translate-y-1 transition-all duration-300"
            >
              View Public Reports
            </Link>
          </motion.div>
        </div>

        {/* Stats Section */}
        <motion.div 
          variants={container}
          initial="hidden"
          whileInView="show"
          viewport={{ once: true, margin: "-100px" }}
          className="grid grid-cols-2 md:grid-cols-4 gap-6 mb-32"
        >
          <motion.div variants={item} className="glass-card p-6 rounded-2xl text-center">
            <h3 className="text-4xl font-display font-bold text-primary mb-2">
              {stats?.total || "0"}
            </h3>
            <p className="text-muted-foreground font-medium">Total Reports</p>
          </motion.div>
          <motion.div variants={item} className="glass-card p-6 rounded-2xl text-center">
            <h3 className="text-4xl font-display font-bold text-success mb-2">
              {stats?.resolved || "0"}
            </h3>
            <p className="text-muted-foreground font-medium">Fixed Hazards</p>
          </motion.div>
          <motion.div variants={item} className="glass-card p-6 rounded-2xl text-center">
            <h3 className="text-4xl font-display font-bold text-warning mb-2">
              {stats?.pending || "0"}
            </h3>
            <p className="text-muted-foreground font-medium">Pending Review</p>
          </motion.div>
          <motion.div variants={item} className="glass-card p-6 rounded-2xl text-center">
            <h3 className="text-4xl font-display font-bold text-info mb-2">
              {stats?.inProgress || "0"}
            </h3>
            <p className="text-muted-foreground font-medium">In Progress</p>
          </motion.div>
        </motion.div>

        {/* Features Section */}
        <div className="mb-24">
          <div className="text-center mb-16">
            <h2 className="text-3xl font-bold mb-4">How It Works</h2>
            <p className="text-muted-foreground max-w-2xl mx-auto">A transparent, efficient process from reporting to resolution.</p>
          </div>

          <div className="grid md:grid-cols-3 gap-8 relative">
            <div className="hidden md:block absolute top-12 left-[15%] right-[15%] h-0.5 bg-gradient-to-r from-transparent via-border to-transparent" />
            
            <div className="relative z-10 flex flex-col items-center text-center">
              <div className="w-24 h-24 rounded-full bg-card border-4 border-background shadow-xl flex items-center justify-center mb-6 relative">
                <Map className="w-10 h-10 text-primary" />
                <div className="absolute -top-2 -right-2 w-8 h-8 rounded-full bg-primary text-primary-foreground flex items-center justify-center font-bold">1</div>
              </div>
              <h3 className="text-xl font-bold mb-3">Pinpoint Location</h3>
              <p className="text-muted-foreground">Drop a pin on our interactive map or use automatic GPS detection to mark the exact spot.</p>
            </div>

            <div className="relative z-10 flex flex-col items-center text-center">
              <div className="w-24 h-24 rounded-full bg-card border-4 border-background shadow-xl flex items-center justify-center mb-6 relative">
                <Activity className="w-10 h-10 text-primary" />
                <div className="absolute -top-2 -right-2 w-8 h-8 rounded-full bg-primary text-primary-foreground flex items-center justify-center font-bold">2</div>
              </div>
              <h3 className="text-xl font-bold mb-3">Provide Details</h3>
              <p className="text-muted-foreground">Select the damage type, add a brief description, and optionally attach a photo.</p>
            </div>

            <div className="relative z-10 flex flex-col items-center text-center">
              <div className="w-24 h-24 rounded-full bg-card border-4 border-background shadow-xl flex items-center justify-center mb-6 relative">
                <ShieldCheck className="w-10 h-10 text-success" />
                <div className="absolute -top-2 -right-2 w-8 h-8 rounded-full bg-success text-success-foreground flex items-center justify-center font-bold">3</div>
              </div>
              <h3 className="text-xl font-bold mb-3">Track Progress</h3>
              <p className="text-muted-foreground">Monitor the status of your report on the public dashboard until the issue is resolved.</p>
            </div>
          </div>
        </div>
      </main>
    </div>
  );
}
