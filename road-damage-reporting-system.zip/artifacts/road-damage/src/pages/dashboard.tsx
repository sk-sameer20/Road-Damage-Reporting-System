import { useState } from "react";
import { Navbar } from "@/components/layout/navbar";
import { useListReports, ListReportsSortBy } from "@workspace/api-client-react";
import { StatusBadge } from "@/components/ui/status-badge";
import { format } from "date-fns";
import { MapPin, Search, Calendar, ChevronLeft, ChevronRight, Loader2, Image as ImageIcon } from "lucide-react";
import { motion } from "framer-motion";

export default function Dashboard() {
  const [page, setPage] = useState(1);
  const [search, setSearch] = useState("");
  const [statusFilter, setStatusFilter] = useState("");
  const [typeFilter, setTypeFilter] = useState("");
  const [sortBy, setSortBy] = useState<ListReportsSortBy>("newest");
  
  // Use debounced search value in real app, keeping simple here
  const { data, isLoading, isError } = useListReports({
    page,
    limit: 12,
    search: search || undefined,
    status: statusFilter || undefined,
    damageType: typeFilter || undefined,
    sortBy
  });

  return (
    <div className="min-h-screen bg-background">
      <Navbar />
      
      <main className="pt-32 pb-24 px-4 sm:px-6 lg:px-8 max-w-7xl mx-auto">
        <div className="flex flex-col md:flex-row justify-between items-start md:items-end mb-10 gap-6">
          <div>
            <h1 className="text-3xl md:text-4xl font-bold mb-3">Public Reports</h1>
            <p className="text-muted-foreground text-lg">Track the status of infrastructure repairs in your area.</p>
          </div>
          
          {/* Filters */}
          <div className="w-full md:w-auto grid grid-cols-2 md:flex gap-3">
            <div className="relative col-span-2 md:col-span-1 md:w-64">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground w-4 h-4" />
              <input 
                placeholder="Search reports..."
                value={search}
                onChange={(e) => setSearch(e.target.value)}
                className="w-full pl-9 pr-4 py-2.5 rounded-xl bg-card border border-border focus:border-primary focus:ring-2 focus:ring-primary/20 transition-all outline-none text-sm"
              />
            </div>
            
            <select 
              value={statusFilter}
              onChange={(e) => setStatusFilter(e.target.value)}
              className="px-4 py-2.5 rounded-xl bg-card border border-border focus:border-primary focus:ring-2 focus:ring-primary/20 transition-all outline-none text-sm appearance-none"
            >
              <option value="">All Statuses</option>
              <option value="pending">Pending Review</option>
              <option value="in_progress">In Progress</option>
              <option value="resolved">Resolved</option>
            </select>
            
            <select 
              value={typeFilter}
              onChange={(e) => setTypeFilter(e.target.value)}
              className="px-4 py-2.5 rounded-xl bg-card border border-border focus:border-primary focus:ring-2 focus:ring-primary/20 transition-all outline-none text-sm appearance-none"
            >
              <option value="">All Types</option>
              <option value="pothole">Pothole</option>
              <option value="crack">Crack</option>
              <option value="road_collapse">Road Collapse</option>
              <option value="flooding">Flooding</option>
              <option value="construction_damage">Construction Damage</option>
            </select>
          </div>
        </div>

        {/* Content */}
        {isLoading ? (
          <div className="flex flex-col items-center justify-center py-32 text-muted-foreground">
            <Loader2 className="w-12 h-12 animate-spin mb-4 text-primary" />
            <p className="text-lg">Loading reports...</p>
          </div>
        ) : isError ? (
          <div className="text-center py-32 text-destructive bg-destructive/5 rounded-2xl border border-destructive/20">
            <p className="text-xl font-bold">Failed to load reports</p>
            <p className="mt-2">Please try refreshing the page.</p>
          </div>
        ) : data?.reports.length === 0 ? (
          <div className="text-center py-32 bg-card rounded-3xl border border-border shadow-sm">
            <div className="w-20 h-20 bg-muted rounded-full flex items-center justify-center mx-auto mb-4">
              <Search className="w-10 h-10 text-muted-foreground" />
            </div>
            <h3 className="text-2xl font-bold mb-2">No reports found</h3>
            <p className="text-muted-foreground">Try adjusting your search or filter criteria.</p>
          </div>
        ) : (
          <>
            <motion.div 
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6"
            >
              {data?.reports.map((report, idx) => (
                <motion.div 
                  key={report.id}
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: idx * 0.05 }}
                  className="bg-card rounded-2xl overflow-hidden border border-border shadow-sm hover:shadow-lg hover:border-primary/30 transition-all duration-300 flex flex-col h-full group"
                >
                  <div className="relative h-48 bg-muted overflow-hidden">
                    {report.imageUrl ? (
                      <img 
                        src={report.imageUrl} 
                        alt="Damage" 
                        className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                        onError={(e) => {
                          e.currentTarget.style.display = 'none';
                          e.currentTarget.parentElement?.classList.add('flex', 'items-center', 'justify-center');
                        }}
                      />
                    ) : (
                      <div className="w-full h-full flex items-center justify-center bg-secondary">
                        <ImageIcon className="w-12 h-12 text-muted-foreground/30" />
                      </div>
                    )}
                    <div className="absolute top-4 left-4">
                      <StatusBadge status={report.status} />
                    </div>
                  </div>
                  
                  <div className="p-6 flex-grow flex flex-col">
                    <div className="flex justify-between items-start mb-2">
                      <h3 className="font-bold text-lg capitalize">{report.damageType.replace('_', ' ')}</h3>
                      <span className="text-xs font-mono text-muted-foreground px-2 py-1 bg-secondary rounded-md">
                        {report.reportId}
                      </span>
                    </div>
                    
                    <p className="text-muted-foreground text-sm mb-4 line-clamp-3 flex-grow">
                      {report.description}
                    </p>
                    
                    <div className="space-y-2 mt-auto pt-4 border-t border-border/50">
                      <div className="flex items-start text-sm text-foreground/80">
                        <MapPin className="w-4 h-4 mr-2 mt-0.5 text-primary shrink-0" />
                        <span className="line-clamp-2">{report.address || `${report.latitude?.toFixed(4)}, ${report.longitude?.toFixed(4)}`}</span>
                      </div>
                      <div className="flex items-center text-sm text-muted-foreground">
                        <Calendar className="w-4 h-4 mr-2" />
                        <span>Reported by {report.name} on {format(new Date(report.createdAt), "MMM d, yyyy")}</span>
                      </div>
                    </div>
                  </div>
                </motion.div>
              ))}
            </motion.div>

            {/* Pagination */}
            {data && data.totalPages > 1 && (
              <div className="mt-12 flex justify-center items-center space-x-2">
                <button
                  onClick={() => setPage(p => Math.max(1, p - 1))}
                  disabled={page === 1}
                  className="p-2 rounded-xl border border-border bg-card text-foreground hover:bg-secondary disabled:opacity-50 disabled:cursor-not-allowed transition-colors"
                >
                  <ChevronLeft className="w-5 h-5" />
                </button>
                <div className="px-4 py-2 font-medium text-sm">
                  Page {page} of {data.totalPages}
                </div>
                <button
                  onClick={() => setPage(p => Math.min(data.totalPages, p + 1))}
                  disabled={page === data.totalPages}
                  className="p-2 rounded-xl border border-border bg-card text-foreground hover:bg-secondary disabled:opacity-50 disabled:cursor-not-allowed transition-colors"
                >
                  <ChevronRight className="w-5 h-5" />
                </button>
              </div>
            )}
          </>
        )}
      </main>
    </div>
  );
}
