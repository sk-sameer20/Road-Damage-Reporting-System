import { useState, useRef, useCallback } from "react";
import { useLocation } from "wouter";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { Navbar } from "@/components/layout/navbar";
import { LocationPicker } from "@/components/map/map-helpers";
import { useCreateReport } from "@workspace/api-client-react";
import { MapPin, UploadCloud, CheckCircle2, AlertCircle, Loader2, X } from "lucide-react";
import { motion, AnimatePresence } from "framer-motion";

const formSchema = z.object({
  name: z.string().min(2, "Name is required"),
  email: z.string().email("Valid email is required"),
  phone: z.string().min(10, "Valid phone number is required"),
  damageType: z.enum(["pothole", "crack", "road_collapse", "flooding", "construction_damage"]),
  description: z.string().min(10, "Please provide more details (min 10 chars)"),
  address: z.string().optional(),
});

type FormData = z.infer<typeof formSchema>;

export default function ReportForm() {
  const [, navigate] = useLocation();
  const [position, setPosition] = useState<[number, number]>([40.7128, -74.0060]);
  const [isLocating, setIsLocating] = useState(false);
  const [isSuccess, setIsSuccess] = useState(false);
  const [reportId, setReportId] = useState<string | null>(null);

  // Image upload state
  const [selectedFile, setSelectedFile] = useState<File | null>(null);
  const [previewUrl, setPreviewUrl] = useState<string | null>(null);
  const [uploadedImageUrl, setUploadedImageUrl] = useState<string | null>(null);
  const [isUploading, setIsUploading] = useState(false);
  const [uploadError, setUploadError] = useState<string | null>(null);
  const [isDragging, setIsDragging] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const { register, handleSubmit, formState: { errors } } = useForm<FormData>({
    resolver: zodResolver(formSchema),
    defaultValues: { damageType: "pothole" }
  });

  const createReport = useCreateReport();

  const handleGeolocation = () => {
    setIsLocating(true);
    if ("geolocation" in navigator) {
      navigator.geolocation.getCurrentPosition(
        (pos) => { setPosition([pos.coords.latitude, pos.coords.longitude]); setIsLocating(false); },
        (err) => { console.error(err); alert("Failed to get location. Please allow location access or select manually."); setIsLocating(false); }
      );
    } else {
      alert("Geolocation is not supported by your browser");
      setIsLocating(false);
    }
  };

  const handleFileSelect = useCallback(async (file: File) => {
    if (!file.type.startsWith("image/")) {
      setUploadError("Only image files are allowed (JPEG, PNG, WEBP, GIF)");
      return;
    }
    if (file.size > 10 * 1024 * 1024) {
      setUploadError("File is too large. Maximum size is 10MB.");
      return;
    }

    setSelectedFile(file);
    setUploadError(null);
    setUploadedImageUrl(null);

    // Create local preview immediately
    const objectUrl = URL.createObjectURL(file);
    setPreviewUrl(objectUrl);

    // Upload to server
    setIsUploading(true);
    try {
      const formData = new FormData();
      formData.append("image", file);
      const res = await fetch("/api/upload", { method: "POST", body: formData });
      if (!res.ok) {
        const err = await res.json();
        throw new Error(err.error || "Upload failed");
      }
      const data = await res.json();
      setUploadedImageUrl(data.imageUrl);
    } catch (err: any) {
      setUploadError(err.message || "Upload failed. Please try again.");
      setSelectedFile(null);
      setPreviewUrl(null);
    } finally {
      setIsUploading(false);
    }
  }, []);

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) handleFileSelect(file);
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(false);
    const file = e.dataTransfer.files?.[0];
    if (file) handleFileSelect(file);
  };

  const clearImage = () => {
    setSelectedFile(null);
    setPreviewUrl(null);
    setUploadedImageUrl(null);
    setUploadError(null);
    if (fileInputRef.current) fileInputRef.current.value = "";
  };

  const onSubmit = (data: FormData) => {
    createReport.mutate({
      data: {
        ...data,
        latitude: position[0],
        longitude: position[1],
        imageUrl: uploadedImageUrl || undefined,
        address: data.address || undefined
      }
    }, {
      onSuccess: (res) => {
        setReportId(res.reportId);
        setIsSuccess(true);
        window.scrollTo({ top: 0, behavior: 'smooth' });
      }
    });
  };

  return (
    <div className="min-h-screen bg-background">
      <Navbar />
      
      <main className="pt-32 pb-24 px-4 sm:px-6 lg:px-8 max-w-4xl mx-auto">
        {isSuccess ? (
          <motion.div 
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            className="glass-card p-12 rounded-3xl text-center shadow-2xl shadow-success/10 border-success/20"
          >
            <div className="w-24 h-24 bg-success/10 rounded-full flex items-center justify-center mx-auto mb-8">
              <CheckCircle2 className="w-12 h-12 text-success" />
            </div>
            <h2 className="text-4xl font-bold mb-4">Report Submitted!</h2>
            <p className="text-xl text-muted-foreground mb-8 max-w-lg mx-auto">
              Thank you for helping improve our community. Your report has been logged and sent to the maintenance team.
            </p>
            <div className="bg-secondary/50 p-6 rounded-2xl mb-10 max-w-sm mx-auto border border-border">
              <p className="text-sm text-muted-foreground uppercase tracking-wider font-bold mb-2">Tracking ID</p>
              <p className="text-3xl font-mono font-bold tracking-widest">{reportId}</p>
            </div>
            <div className="flex justify-center space-x-4">
              <button 
                onClick={() => { setIsSuccess(false); setReportId(null); }}
                className="px-6 py-3 rounded-xl font-bold bg-secondary hover:bg-secondary/80 transition-colors"
              >
                Submit Another
              </button>
              <button 
                onClick={() => navigate('/dashboard')}
                className="px-6 py-3 rounded-xl font-bold bg-primary text-primary-foreground hover:bg-primary/90 shadow-lg shadow-primary/25 transition-colors"
              >
                Go to Dashboard
              </button>
            </div>
          </motion.div>
        ) : (
          <motion.div 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="glass-card p-8 md:p-10 rounded-3xl shadow-xl"
          >
            <div className="mb-10">
              <h1 className="text-3xl md:text-4xl font-bold mb-3">Report Road Damage</h1>
              <p className="text-muted-foreground text-lg">Help us locate and fix infrastructure issues quickly.</p>
            </div>

            <form onSubmit={handleSubmit(onSubmit)} className="space-y-8">
              
              {/* Location Section */}
              <div className="space-y-4">
                <div className="flex items-center justify-between">
                  <h3 className="text-xl font-bold flex items-center">
                    <MapPin className="mr-2 text-primary w-5 h-5" />
                    1. Pinpoint Location
                  </h3>
                  <button 
                    type="button"
                    onClick={handleGeolocation}
                    disabled={isLocating}
                    className="text-sm px-4 py-2 bg-primary/10 text-primary font-medium rounded-lg hover:bg-primary/20 transition-colors flex items-center"
                  >
                    {isLocating ? <Loader2 className="w-4 h-4 mr-2 animate-spin" /> : <MapPin className="w-4 h-4 mr-2" />}
                    Use My Location
                  </button>
                </div>
                
                <LocationPicker position={position} setPosition={setPosition} height="350px" />
                
                <div className="mt-4">
                  <label className="block text-sm font-medium mb-2">Street Address (Optional)</label>
                  <input 
                    {...register("address")}
                    placeholder="e.g. 123 Main St, near the intersection"
                    className="w-full px-4 py-3 rounded-xl bg-background border-2 border-border focus:border-primary focus:ring-4 focus:ring-primary/10 transition-all outline-none"
                  />
                </div>
              </div>

              <hr className="border-border/50" />

              {/* Details Section */}
              <div className="space-y-6">
                <h3 className="text-xl font-bold flex items-center">
                  <AlertCircle className="mr-2 text-primary w-5 h-5" />
                  2. Damage Details
                </h3>

                <div className="grid md:grid-cols-2 gap-6">
                  <div>
                    <label className="block text-sm font-medium mb-2">Damage Type <span className="text-destructive">*</span></label>
                    <select 
                      {...register("damageType")}
                      className="w-full px-4 py-3 rounded-xl bg-background border-2 border-border focus:border-primary focus:ring-4 focus:ring-primary/10 transition-all outline-none appearance-none"
                    >
                      <option value="pothole">Pothole</option>
                      <option value="crack">Road Crack</option>
                      <option value="road_collapse">Road Collapse / Sinkhole</option>
                      <option value="flooding">Severe Flooding</option>
                      <option value="construction_damage">Construction Damage</option>
                    </select>
                    {errors.damageType && <p className="text-destructive text-sm mt-1">{errors.damageType.message}</p>}
                  </div>

                  <div>
                    <label className="block text-sm font-medium mb-2">Photo Upload (Optional)</label>

                    <AnimatePresence mode="wait">
                      {!previewUrl ? (
                        <motion.div
                          key="dropzone"
                          initial={{ opacity: 0 }}
                          animate={{ opacity: 1 }}
                          exit={{ opacity: 0 }}
                          onDragOver={(e) => { e.preventDefault(); setIsDragging(true); }}
                          onDragLeave={() => setIsDragging(false)}
                          onDrop={handleDrop}
                          onClick={() => fileInputRef.current?.click()}
                          className={`relative cursor-pointer rounded-xl border-2 border-dashed transition-all duration-200 p-6 flex flex-col items-center justify-center gap-3 text-center min-h-[130px]
                            ${isDragging
                              ? "border-primary bg-primary/10 scale-[1.01]"
                              : "border-border bg-background hover:border-primary/50 hover:bg-primary/5"
                            }`}
                        >
                          <div className="w-12 h-12 rounded-full bg-primary/10 flex items-center justify-center">
                            <UploadCloud className="w-6 h-6 text-primary" />
                          </div>
                          <div>
                            <p className="font-semibold text-sm">Click to upload or drag & drop</p>
                            <p className="text-xs text-muted-foreground mt-0.5">JPEG, PNG, WEBP, GIF — max 10 MB</p>
                          </div>
                          <input
                            ref={fileInputRef}
                            type="file"
                            accept="image/*"
                            className="hidden"
                            onChange={handleInputChange}
                          />
                        </motion.div>
                      ) : (
                        <motion.div
                          key="preview"
                          initial={{ opacity: 0, scale: 0.95 }}
                          animate={{ opacity: 1, scale: 1 }}
                          exit={{ opacity: 0, scale: 0.95 }}
                          className="relative rounded-xl overflow-hidden border-2 border-border bg-black/5"
                        >
                          <img
                            src={previewUrl}
                            alt="Preview"
                            className="w-full h-48 object-cover"
                          />
                          <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent" />

                          {/* Status overlay */}
                          <div className="absolute bottom-3 left-3 right-3 flex items-center justify-between">
                            <div className="flex items-center gap-2">
                              {isUploading ? (
                                <div className="flex items-center gap-1.5 bg-black/60 text-white text-xs px-3 py-1.5 rounded-full">
                                  <Loader2 className="w-3.5 h-3.5 animate-spin" />
                                  Uploading…
                                </div>
                              ) : uploadedImageUrl ? (
                                <div className="flex items-center gap-1.5 bg-green-600/90 text-white text-xs px-3 py-1.5 rounded-full">
                                  <CheckCircle2 className="w-3.5 h-3.5" />
                                  Uploaded
                                </div>
                              ) : null}
                              <span className="text-white/80 text-xs truncate max-w-[160px]">{selectedFile?.name}</span>
                            </div>
                            <button
                              type="button"
                              onClick={clearImage}
                              className="w-7 h-7 bg-black/60 hover:bg-black/80 text-white rounded-full flex items-center justify-center transition-colors"
                            >
                              <X className="w-4 h-4" />
                            </button>
                          </div>
                        </motion.div>
                      )}
                    </AnimatePresence>

                    {uploadError && (
                      <p className="text-destructive text-sm mt-2 flex items-center gap-1">
                        <AlertCircle className="w-4 h-4 flex-shrink-0" />
                        {uploadError}
                      </p>
                    )}
                  </div>
                </div>

                <div>
                  <label className="block text-sm font-medium mb-2">Description <span className="text-destructive">*</span></label>
                  <textarea 
                    {...register("description")}
                    rows={4}
                    placeholder="Describe the size, depth, and exact position on the road..."
                    className="w-full px-4 py-3 rounded-xl bg-background border-2 border-border focus:border-primary focus:ring-4 focus:ring-primary/10 transition-all outline-none resize-y"
                  ></textarea>
                  {errors.description && <p className="text-destructive text-sm mt-1">{errors.description.message}</p>}
                </div>
              </div>

              <hr className="border-border/50" />

              {/* Contact Section */}
              <div className="space-y-6">
                <h3 className="text-xl font-bold">3. Your Information</h3>
                
                <div className="grid md:grid-cols-2 gap-6">
                  <div>
                    <label className="block text-sm font-medium mb-2">Full Name <span className="text-destructive">*</span></label>
                    <input 
                      {...register("name")}
                      className="w-full px-4 py-3 rounded-xl bg-background border-2 border-border focus:border-primary focus:ring-4 focus:ring-primary/10 transition-all outline-none"
                    />
                    {errors.name && <p className="text-destructive text-sm mt-1">{errors.name.message}</p>}
                  </div>

                  <div>
                    <label className="block text-sm font-medium mb-2">Email Address <span className="text-destructive">*</span></label>
                    <input 
                      {...register("email")}
                      type="email"
                      className="w-full px-4 py-3 rounded-xl bg-background border-2 border-border focus:border-primary focus:ring-4 focus:ring-primary/10 transition-all outline-none"
                    />
                    {errors.email && <p className="text-destructive text-sm mt-1">{errors.email.message}</p>}
                  </div>

                  <div className="md:col-span-2">
                    <label className="block text-sm font-medium mb-2">Phone Number <span className="text-destructive">*</span></label>
                    <input 
                      {...register("phone")}
                      className="w-full px-4 py-3 rounded-xl bg-background border-2 border-border focus:border-primary focus:ring-4 focus:ring-primary/10 transition-all outline-none"
                    />
                    {errors.phone && <p className="text-destructive text-sm mt-1">{errors.phone.message}</p>}
                  </div>
                </div>
              </div>

              <div className="pt-6">
                <button 
                  type="submit"
                  disabled={createReport.isPending}
                  className="w-full py-4 rounded-xl font-bold text-lg bg-gradient-to-r from-primary to-info text-primary-foreground shadow-xl shadow-primary/25 hover:shadow-2xl hover:-translate-y-1 active:translate-y-0 active:shadow-md disabled:opacity-50 disabled:cursor-not-allowed disabled:transform-none transition-all duration-300 flex justify-center items-center"
                >
                  {createReport.isPending ? (
                    <><Loader2 className="w-5 h-5 animate-spin mr-2" /> Submitting Report...</>
                  ) : (
                    "Submit Report"
                  )}
                </button>
              </div>

            </form>
          </motion.div>
        )}
      </main>
    </div>
  );
}
