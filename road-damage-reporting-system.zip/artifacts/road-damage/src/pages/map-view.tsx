import { Navbar } from "@/components/layout/navbar";
import { ReportsMap } from "@/components/map/map-helpers";
import { useListReports } from "@workspace/api-client-react";
import { Loader2 } from "lucide-react";

export default function MapView() {
  // Fetch a larger chunk for the map overview
  const { data, isLoading } = useListReports({ limit: 500 });

  return (
    <div className="h-screen bg-background flex flex-col overflow-hidden">
      <Navbar />
      
      <main className="flex-grow pt-20 relative flex">
        {isLoading ? (
          <div className="absolute inset-0 flex flex-col items-center justify-center bg-background/50 backdrop-blur-sm z-10">
            <Loader2 className="w-12 h-12 animate-spin text-primary mb-4" />
            <p className="text-xl font-medium">Loading map data...</p>
          </div>
        ) : null}
        
        <div className="w-full h-full p-4 pb-0">
          <div className="w-full h-full rounded-t-3xl overflow-hidden border-t border-x border-border shadow-2xl relative">
            
            {/* Map Legend Overlay */}
            <div className="absolute top-6 right-6 z-[400] glass-card p-4 rounded-xl shadow-xl border border-border w-48 hidden md:block">
              <h4 className="font-bold text-sm mb-3 uppercase tracking-wider">Damage Types</h4>
              <div className="space-y-2 text-sm">
                <div className="flex items-center"><div className="w-3 h-3 rounded-full bg-[#ef4444] mr-2" /> Pothole</div>
                <div className="flex items-center"><div className="w-3 h-3 rounded-full bg-[#f59e0b] mr-2" /> Crack</div>
                <div className="flex items-center"><div className="w-3 h-3 rounded-full bg-[#7f1d1d] mr-2" /> Road Collapse</div>
                <div className="flex items-center"><div className="w-3 h-3 rounded-full bg-[#0ea5e9] mr-2" /> Flooding</div>
                <div className="flex items-center"><div className="w-3 h-3 rounded-full bg-[#8b5cf6] mr-2" /> Construction</div>
              </div>
            </div>

            <ReportsMap reports={data?.reports || []} height="100%" />
          </div>
        </div>
      </main>
    </div>
  );
}
