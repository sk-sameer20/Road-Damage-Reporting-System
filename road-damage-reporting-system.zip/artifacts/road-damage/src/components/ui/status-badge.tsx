import { clsx, type ClassValue } from "clsx";
import { twMerge } from "tailwind-merge";

function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}

export function StatusBadge({ status }: { status: string }) {
  const configs: Record<string, { label: string; className: string }> = {
    pending: {
      label: "Pending Review",
      className: "bg-warning/15 text-warning-foreground border-warning/20",
    },
    in_progress: {
      label: "In Progress",
      className: "bg-info/15 text-info-foreground border-info/20",
    },
    resolved: {
      label: "Resolved",
      className: "bg-success/15 text-success-foreground border-success/20",
    },
  };

  const config = configs[status] || configs.pending;

  return (
    <span className={cn(
      "px-3 py-1 text-xs font-semibold rounded-full border shadow-sm backdrop-blur-sm",
      config.className
    )}>
      {config.label}
    </span>
  );
}
