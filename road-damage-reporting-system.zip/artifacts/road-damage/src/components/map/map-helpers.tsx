import { useEffect, useState } from "react";
import { MapContainer, TileLayer, Marker, Popup, useMapEvents, useMap } from "react-leaflet";
import L from "leaflet";
import { Report } from "@workspace/api-client-react";
import { StatusBadge } from "../ui/status-badge";
import { MapPin } from "lucide-react";
import { format } from "date-fns";

// Custom marker icon creation to avoid Vite asset pipeline issues with Leaflet
const createCustomIcon = (color: string) => L.divIcon({
  className: 'custom-div-icon',
  html: `<div class="marker-pin" style="background-color: ${color}"></div>`,
  iconSize: [30, 42],
  iconAnchor: [15, 42],
  popupAnchor: [0, -35]
});

const getDamageColor = (type: string) => {
  switch(type) {
    case 'pothole': return '#ef4444'; // destructive
    case 'crack': return '#f59e0b'; // warning
    case 'road_collapse': return '#7f1d1d'; // dark red
    case 'flooding': return '#0ea5e9'; // blue
    case 'construction_damage': return '#8b5cf6'; // purple
    default: return '#3b82f6'; // primary
  }
};

export function DraggableMarker({ position, setPosition }: { position: [number, number], setPosition: (pos: [number, number]) => void }) {
  const map = useMap();
  
  useEffect(() => {
    map.flyTo(position, map.getZoom());
  }, [position, map]);

  const markerEventHandlers = {
    dragend(e: any) {
      const marker = e.target;
      const pos = marker.getLatLng();
      setPosition([pos.lat, pos.lng]);
    },
  };

  return (
    <Marker
      draggable={true}
      eventHandlers={markerEventHandlers}
      position={position}
      icon={createCustomIcon('#3b82f6')}
    >
      <Popup minWidth={90}>
        <div className="text-center font-medium">Drag to adjust</div>
      </Popup>
    </Marker>
  );
}

export function MapClickSelector({ setPosition }: { setPosition: (pos: [number, number]) => void }) {
  useMapEvents({
    click(e) {
      setPosition([e.latlng.lat, e.latlng.lng]);
    },
  });
  return null;
}

export function ReportsMap({ reports, height = "500px" }: { reports: Report[], height?: string }) {
  const center: [number, number] = reports.length > 0 && reports[0].latitude && reports[0].longitude 
    ? [reports[0].latitude, reports[0].longitude] 
    : [40.7128, -74.0060]; // Default to NYC if no reports

  return (
    <div style={{ height }} className="w-full rounded-2xl overflow-hidden border border-border shadow-md z-0 relative">
      <MapContainer center={center} zoom={13} style={{ height: "100%", width: "100%" }}>
        <TileLayer
          attribution='&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a>'
          url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
          className="map-tiles"
        />
        {reports.map((report) => {
          if (!report.latitude || !report.longitude) return null;
          
          return (
            <Marker 
              key={report.id} 
              position={[report.latitude, report.longitude]}
              icon={createCustomIcon(getDamageColor(report.damageType))}
            >
              <Popup className="rounded-xl overflow-hidden shadow-xl border-0 p-0">
                <div className="p-1 min-w-[200px]">
                  <div className="mb-2">
                    <StatusBadge status={report.status} />
                  </div>
                  <h3 className="font-bold text-base capitalize mb-1">
                    {report.damageType.replace('_', ' ')}
                  </h3>
                  <p className="text-sm text-muted-foreground line-clamp-2 mb-2">
                    {report.description}
                  </p>
                  <div className="text-xs text-muted-foreground flex items-center">
                    <MapPin className="w-3 h-3 mr-1" />
                    {report.address || "Location set via map"}
                  </div>
                  <div className="text-xs text-muted-foreground mt-2 border-t pt-2">
                    Reported on {format(new Date(report.createdAt), "MMM d, yyyy")}
                  </div>
                </div>
              </Popup>
            </Marker>
          );
        })}
      </MapContainer>
      <style dangerouslySetContent={{ __html: `
        .dark .map-tiles { filter: brightness(0.6) invert(1) contrast(3) hue-rotate(200deg) saturate(0.3) brightness(0.7); }
        .leaflet-popup-content-wrapper { border-radius: 0.75rem; background: hsl(var(--card)); color: hsl(var(--foreground)); box-shadow: var(--shadow-glass); border: 1px solid hsl(var(--border)); }
        .leaflet-popup-tip { background: hsl(var(--card)); }
      `}} />
    </div>
  );
}

export function LocationPicker({ position, setPosition, height = "300px" }: { position: [number, number], setPosition: (pos: [number, number]) => void, height?: string }) {
  return (
    <div style={{ height }} className="w-full rounded-2xl overflow-hidden border border-border/50 shadow-inner z-0 relative">
      <MapContainer center={position} zoom={15} style={{ height: "100%", width: "100%" }}>
        <TileLayer
          attribution='&copy; OpenStreetMap'
          url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
          className="map-tiles"
        />
        <DraggableMarker position={position} setPosition={setPosition} />
        <MapClickSelector setPosition={setPosition} />
      </MapContainer>
      <style dangerouslySetContent={{ __html: `
        .dark .map-tiles { filter: brightness(0.6) invert(1) contrast(3) hue-rotate(200deg) saturate(0.3) brightness(0.7); }
      `}} />
    </div>
  );
}
